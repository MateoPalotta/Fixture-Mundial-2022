<?php

/**
* getLookupMainTableSettings - tests whether the lookup link exists between the tables
*
*  returns array with ProjectSettings class for main table if the link exists in project settings.
*  returns NULL otherwise
*/
function getLookupMainTableSettings($lookupTable, $mainTableShortName, $mainField, $desiredPage = "")
{
	global $lookupTableLinks;
	if(!isset($lookupTableLinks[$lookupTable]))
		return null;
	if(!isset($lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField]))
		return null;
	$arr = &$lookupTableLinks[$lookupTable][$mainTableShortName.".".$mainField];
	$effectivePage = $desiredPage;
	if(!isset($arr[$effectivePage]))
	{
		$effectivePage = PAGE_EDIT;
		if(!isset($arr[$effectivePage]))
		{
			if($desiredPage == "" && 0 < count($arr))
			{
				$effectivePage = $arr[0];
			}
			else
				return null;
		}
	}
	return new ProjectSettings($arr[$effectivePage]["table"], $effectivePage);
}

/** 
* $lookupTableLinks array stores all lookup links between tables in the project
*/
function InitLookupLinks()
{
	global $lookupTableLinks;

	$lookupTableLinks = array();

		if( !isset( $lookupTableLinks["colores"] ) ) {
			$lookupTableLinks["colores"] = array();
		}
		if( !isset( $lookupTableLinks["colores"]["selecciones.id_colorcamiseta"] )) {
			$lookupTableLinks["colores"]["selecciones.id_colorcamiseta"] = array();
		}
		$lookupTableLinks["colores"]["selecciones.id_colorcamiseta"]["edit"] = array("table" => "selecciones", "field" => "id_colorcamiseta", "page" => "edit");
		if( !isset( $lookupTableLinks["colores"] ) ) {
			$lookupTableLinks["colores"] = array();
		}
		if( !isset( $lookupTableLinks["colores"]["selecciones.id_colorpantalon"] )) {
			$lookupTableLinks["colores"]["selecciones.id_colorpantalon"] = array();
		}
		$lookupTableLinks["colores"]["selecciones.id_colorpantalon"]["edit"] = array("table" => "selecciones", "field" => "id_colorpantalon", "page" => "edit");
		if( !isset( $lookupTableLinks["colores"] ) ) {
			$lookupTableLinks["colores"] = array();
		}
		if( !isset( $lookupTableLinks["colores"]["selecciones.id_colormedias"] )) {
			$lookupTableLinks["colores"]["selecciones.id_colormedias"] = array();
		}
		$lookupTableLinks["colores"]["selecciones.id_colormedias"]["edit"] = array("table" => "selecciones", "field" => "id_colormedias", "page" => "edit");
		if( !isset( $lookupTableLinks["dts"] ) ) {
			$lookupTableLinks["dts"] = array();
		}
		if( !isset( $lookupTableLinks["dts"]["selecciones.id_dt"] )) {
			$lookupTableLinks["dts"]["selecciones.id_dt"] = array();
		}
		$lookupTableLinks["dts"]["selecciones.id_dt"]["edit"] = array("table" => "selecciones", "field" => "id_dt", "page" => "edit");
		if( !isset( $lookupTableLinks["partidos"] ) ) {
			$lookupTableLinks["partidos"] = array();
		}
		if( !isset( $lookupTableLinks["partidos"]["goles.id_partido"] )) {
			$lookupTableLinks["partidos"]["goles.id_partido"] = array();
		}
		$lookupTableLinks["partidos"]["goles.id_partido"]["edit"] = array("table" => "goles", "field" => "id_partido", "page" => "edit");
		if( !isset( $lookupTableLinks["jugadores"] ) ) {
			$lookupTableLinks["jugadores"] = array();
		}
		if( !isset( $lookupTableLinks["jugadores"]["goles.id_jugador"] )) {
			$lookupTableLinks["jugadores"]["goles.id_jugador"] = array();
		}
		$lookupTableLinks["jugadores"]["goles.id_jugador"]["edit"] = array("table" => "goles", "field" => "id_jugador", "page" => "edit");
		if( !isset( $lookupTableLinks["tipodegol"] ) ) {
			$lookupTableLinks["tipodegol"] = array();
		}
		if( !isset( $lookupTableLinks["tipodegol"]["goles.id_tipodegol"] )) {
			$lookupTableLinks["tipodegol"]["goles.id_tipodegol"] = array();
		}
		$lookupTableLinks["tipodegol"]["goles.id_tipodegol"]["edit"] = array("table" => "goles", "field" => "id_tipodegol", "page" => "edit");
		if( !isset( $lookupTableLinks["partidos"] ) ) {
			$lookupTableLinks["partidos"] = array();
		}
		if( !isset( $lookupTableLinks["partidos"]["cambios.id_partido"] )) {
			$lookupTableLinks["partidos"]["cambios.id_partido"] = array();
		}
		$lookupTableLinks["partidos"]["cambios.id_partido"]["edit"] = array("table" => "cambios", "field" => "id_partido", "page" => "edit");
		if( !isset( $lookupTableLinks["jugadores"] ) ) {
			$lookupTableLinks["jugadores"] = array();
		}
		if( !isset( $lookupTableLinks["jugadores"]["cambios.id_jugadorfuera"] )) {
			$lookupTableLinks["jugadores"]["cambios.id_jugadorfuera"] = array();
		}
		$lookupTableLinks["jugadores"]["cambios.id_jugadorfuera"]["edit"] = array("table" => "cambios", "field" => "id_jugadorfuera", "page" => "edit");
		if( !isset( $lookupTableLinks["jugadores"] ) ) {
			$lookupTableLinks["jugadores"] = array();
		}
		if( !isset( $lookupTableLinks["jugadores"]["cambios.id_jugadoradentro"] )) {
			$lookupTableLinks["jugadores"]["cambios.id_jugadoradentro"] = array();
		}
		$lookupTableLinks["jugadores"]["cambios.id_jugadoradentro"]["edit"] = array("table" => "cambios", "field" => "id_jugadoradentro", "page" => "edit");
		if( !isset( $lookupTableLinks["selecciones"] ) ) {
			$lookupTableLinks["selecciones"] = array();
		}
		if( !isset( $lookupTableLinks["selecciones"]["partidos.id_seleccionlocal"] )) {
			$lookupTableLinks["selecciones"]["partidos.id_seleccionlocal"] = array();
		}
		$lookupTableLinks["selecciones"]["partidos.id_seleccionlocal"]["edit"] = array("table" => "partidos", "field" => "id_seleccionlocal", "page" => "edit");
		if( !isset( $lookupTableLinks["selecciones"] ) ) {
			$lookupTableLinks["selecciones"] = array();
		}
		if( !isset( $lookupTableLinks["selecciones"]["partidos.id_seleccionvisitante"] )) {
			$lookupTableLinks["selecciones"]["partidos.id_seleccionvisitante"] = array();
		}
		$lookupTableLinks["selecciones"]["partidos.id_seleccionvisitante"]["edit"] = array("table" => "partidos", "field" => "id_seleccionvisitante", "page" => "edit");
		if( !isset( $lookupTableLinks["estadios"] ) ) {
			$lookupTableLinks["estadios"] = array();
		}
		if( !isset( $lookupTableLinks["estadios"]["partidos.id_estadio"] )) {
			$lookupTableLinks["estadios"]["partidos.id_estadio"] = array();
		}
		$lookupTableLinks["estadios"]["partidos.id_estadio"]["edit"] = array("table" => "partidos", "field" => "id_estadio", "page" => "edit");
		if( !isset( $lookupTableLinks["selecciones"] ) ) {
			$lookupTableLinks["selecciones"] = array();
		}
		if( !isset( $lookupTableLinks["selecciones"]["jugadores.nombre_seleccion"] )) {
			$lookupTableLinks["selecciones"]["jugadores.nombre_seleccion"] = array();
		}
		$lookupTableLinks["selecciones"]["jugadores.nombre_seleccion"]["edit"] = array("table" => "jugadores", "field" => "nombre_seleccion", "page" => "edit");
		if( !isset( $lookupTableLinks["posiciones"] ) ) {
			$lookupTableLinks["posiciones"] = array();
		}
		if( !isset( $lookupTableLinks["posiciones"]["jugadores.id_posicion"] )) {
			$lookupTableLinks["posiciones"]["jugadores.id_posicion"] = array();
		}
		$lookupTableLinks["posiciones"]["jugadores.id_posicion"]["edit"] = array("table" => "jugadores", "field" => "id_posicion", "page" => "edit");
}

?>