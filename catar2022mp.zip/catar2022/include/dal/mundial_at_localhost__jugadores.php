<?php
$dalTablejugadores = array();
$dalTablejugadores["id_jugador"] = array("type"=>3,"varname"=>"id_jugador", "name" => "id_jugador");
$dalTablejugadores["nombre_seleccion"] = array("type"=>200,"varname"=>"nombre_seleccion", "name" => "nombre_seleccion");
$dalTablejugadores["nombre_apellido"] = array("type"=>200,"varname"=>"nombre_apellido", "name" => "nombre_apellido");
$dalTablejugadores["numero_camiseta"] = array("type"=>3,"varname"=>"numero_camiseta", "name" => "numero_camiseta");
$dalTablejugadores["id_posicion"] = array("type"=>3,"varname"=>"id_posicion", "name" => "id_posicion");
	$dalTablejugadores["id_jugador"]["key"]=true;

$dal_info["mundial_at_localhost__jugadores"] = &$dalTablejugadores;
?>