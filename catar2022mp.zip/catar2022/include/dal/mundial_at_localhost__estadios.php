<?php
$dalTableestadios = array();
$dalTableestadios["id_estadio"] = array("type"=>3,"varname"=>"id_estadio", "name" => "id_estadio");
$dalTableestadios["nombre_estadio"] = array("type"=>200,"varname"=>"nombre_estadio", "name" => "nombre_estadio");
$dalTableestadios["capacidad_estadio"] = array("type"=>200,"varname"=>"capacidad_estadio", "name" => "capacidad_estadio");
$dalTableestadios["ciudad_estadio"] = array("type"=>200,"varname"=>"ciudad_estadio", "name" => "ciudad_estadio");
	$dalTableestadios["id_estadio"]["key"]=true;

$dal_info["mundial_at_localhost__estadios"] = &$dalTableestadios;
?>