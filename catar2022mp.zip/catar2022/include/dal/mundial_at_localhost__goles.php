<?php
$dalTablegoles = array();
$dalTablegoles["id_partido"] = array("type"=>3,"varname"=>"id_partido", "name" => "id_partido");
$dalTablegoles["id_jugador"] = array("type"=>3,"varname"=>"id_jugador", "name" => "id_jugador");
$dalTablegoles["id_tipodegol"] = array("type"=>3,"varname"=>"id_tipodegol", "name" => "id_tipodegol");
$dalTablegoles["mingol"] = array("type"=>3,"varname"=>"mingol", "name" => "mingol");
	$dalTablegoles["id_partido"]["key"]=true;

$dal_info["mundial_at_localhost__goles"] = &$dalTablegoles;
?>