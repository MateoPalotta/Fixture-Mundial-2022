<?php
$dalTabletipodegol = array();
$dalTabletipodegol["idtipodegol"] = array("type"=>3,"varname"=>"idtipodegol", "name" => "idtipodegol");
$dalTabletipodegol["tipogol"] = array("type"=>200,"varname"=>"tipogol", "name" => "tipogol");
	$dalTabletipodegol["idtipodegol"]["key"]=true;

$dal_info["mundial_at_localhost__tipodegol"] = &$dalTabletipodegol;
?>