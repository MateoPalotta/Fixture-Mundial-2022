<?php
$dalTabledts = array();
$dalTabledts["id_dt"] = array("type"=>3,"varname"=>"id_dt", "name" => "id_dt");
$dalTabledts["nombreyapellido"] = array("type"=>200,"varname"=>"nombreyapellido", "name" => "nombreyapellido");
$dalTabledts["fecha_llegada"] = array("type"=>200,"varname"=>"fecha_llegada", "name" => "fecha_llegada");
	$dalTabledts["id_dt"]["key"]=true;

$dal_info["mundial_at_localhost__dts"] = &$dalTabledts;
?>