<?php
$dalTableposiciones = array();
$dalTableposiciones["id_posicion"] = array("type"=>200,"varname"=>"id_posicion", "name" => "id_posicion");
$dalTableposiciones["posicion"] = array("type"=>200,"varname"=>"posicion", "name" => "posicion");
	$dalTableposiciones["id_posicion"]["key"]=true;

$dal_info["mundial_at_localhost__posiciones"] = &$dalTableposiciones;
?>