<?php
$dalTablecambios = array();
$dalTablecambios["Idcambio"] = array("type"=>200,"varname"=>"Idcambio", "name" => "Idcambio");
$dalTablecambios["id_partido"] = array("type"=>3,"varname"=>"id_partido", "name" => "id_partido");
$dalTablecambios["id_jugadorfuera"] = array("type"=>3,"varname"=>"id_jugadorfuera", "name" => "id_jugadorfuera");
$dalTablecambios["id_jugadoradentro"] = array("type"=>3,"varname"=>"id_jugadoradentro", "name" => "id_jugadoradentro");
$dalTablecambios["mindelcambio"] = array("type"=>3,"varname"=>"mindelcambio", "name" => "mindelcambio");
	$dalTablecambios["Idcambio"]["key"]=true;

$dal_info["mundial_at_localhost__cambios"] = &$dalTablecambios;
?>