<?php
$dalTablepartidos = array();
$dalTablepartidos["id_partido"] = array("type"=>3,"varname"=>"id_partido", "name" => "id_partido");
$dalTablepartidos["id_seleccionlocal"] = array("type"=>3,"varname"=>"id_seleccionlocal", "name" => "id_seleccionlocal");
$dalTablepartidos["id_seleccionvisitante"] = array("type"=>3,"varname"=>"id_seleccionvisitante", "name" => "id_seleccionvisitante");
$dalTablepartidos["id_estadio"] = array("type"=>3,"varname"=>"id_estadio", "name" => "id_estadio");
$dalTablepartidos["fecha"] = array("type"=>7,"varname"=>"fecha", "name" => "fecha");
$dalTablepartidos["hora"] = array("type"=>134,"varname"=>"hora", "name" => "hora");
$dalTablepartidos["cant_goleslocal"] = array("type"=>3,"varname"=>"cant_goleslocal", "name" => "cant_goleslocal");
$dalTablepartidos["cant_golesvisitante"] = array("type"=>200,"varname"=>"cant_golesvisitante", "name" => "cant_golesvisitante");
	$dalTablepartidos["id_partido"]["key"]=true;

$dal_info["mundial_at_localhost__partidos"] = &$dalTablepartidos;
?>