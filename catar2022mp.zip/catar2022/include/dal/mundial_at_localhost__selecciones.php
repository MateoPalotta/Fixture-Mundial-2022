<?php
$dalTableselecciones = array();
$dalTableselecciones["id_seleccion"] = array("type"=>3,"varname"=>"id_seleccion", "name" => "id_seleccion");
$dalTableselecciones["nombre_seleccion"] = array("type"=>200,"varname"=>"nombre_seleccion", "name" => "nombre_seleccion");
$dalTableselecciones["id_colorcamiseta"] = array("type"=>3,"varname"=>"id_colorcamiseta", "name" => "id_colorcamiseta");
$dalTableselecciones["id_colorpantalon"] = array("type"=>3,"varname"=>"id_colorpantalon", "name" => "id_colorpantalon");
$dalTableselecciones["id_colormedias"] = array("type"=>3,"varname"=>"id_colormedias", "name" => "id_colormedias");
$dalTableselecciones["id_dt"] = array("type"=>3,"varname"=>"id_dt", "name" => "id_dt");
	$dalTableselecciones["id_seleccion"]["key"]=true;

$dal_info["mundial_at_localhost__selecciones"] = &$dalTableselecciones;
?>