<?php
$dalTablecolores = array();
$dalTablecolores["id_color"] = array("type"=>3,"varname"=>"id_color", "name" => "id_color");
$dalTablecolores["nombre_color"] = array("type"=>200,"varname"=>"nombre_color", "name" => "nombre_color");
	$dalTablecolores["id_color"]["key"]=true;

$dal_info["mundial_at_localhost__colores"] = &$dalTablecolores;
?>