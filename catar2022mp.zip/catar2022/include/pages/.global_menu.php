<?php
			$optionsArray = array( 'welcome' => array( 'welcomeItems' => array( 'logo' => array( 'menutItem' => false ),
'menu' => array( 'menutItem' => false ) ) ),
'fields' => array( 'gridFields' => array(  ),
'searchRequiredFields' => array(  ),
'searchPanelFields' => array(  ),
'fieldItems' => array(  ) ),
'layoutHelper' => array( 'formItems' => array( 'formItems' => array( 'supertop' => array( 'logo',
'menu' ),
'above-grid' => array(  ),
'grid' => array(  ) ),
'formXtTags' => array( 'above-grid' => array(  ),
'grid' => array(  ) ),
'itemForms' => array( 'logo' => 'supertop',
'menu' => 'supertop' ),
'itemLocations' => array(  ),
'itemVisiblity' => array( 'menu' => 3 ) ),
'itemsByType' => array( 'logo' => array( 'logo' ),
'menu' => array( 'menu' ) ),
'cellMaps' => array(  ) ),
'page' => array( 'labeledButtons' => array( 'update_records' => array(  ),
'print_pages' => array(  ),
'register_activate_message' => array(  ),
'details_found' => array(  ) ),
'hasCustomButtons' => false,
'customButtons' => array(  ) ),
'events' => array( 'maps' => array(  ),
'mapsData' => array(  ),
'buttons' => array(  ) ) );
			$pageArray = array( 'id' => 'menu',
'type' => 'menu',
'layoutId' => 'topbar',
'disabled' => 0,
'default' => 0,
'forms' => array( 'supertop' => array( 'modelId' => 'menu-topbar-menu',
'grid' => array( array( 'cells' => array( array( 'cell' => 'c1' ),
array( 'cell' => 'c2' ) ),
'section' => '' ) ),
'cells' => array( 'c1' => array( 'model' => 'c1',
'items' => array( 'logo',
'menu' ),
'_t' => 'Map',
'_i' => array(  ),
'_s' => 0,
'color' => '#ffffff',
'customCSS' => '/* Put  your custom CSS code here */

:host {
  color: red;
}
.navbar-default{
      font-family: \'QatarBold\';
    background: rgb(128, 25, 45);
  background: linear-gradient(120deg, rgba(117,25,43,1) 0%, rgb(35, 6, 16) 100%);
  margin: 0;
}
.navbar-brand{
    width: 200;
}' ),
'c2' => array( 'model' => 'c2',
'items' => array(  ),
'_t' => 'Map',
'_i' => array(  ),
'_s' => 0,
'color' => '#ffffff',
'customCSS' => '/* Put  your custom CSS code here */

:host {
  color: red;
}
.navbar-default{
      font-family: \'QatarBold\';
    background: rgb(128, 25, 45);
  background: linear-gradient(120deg, rgba(117,25,43,1) 0%, rgb(35, 6, 16) 100%);
  margin: 0;
}' ) ),
'deferredItems' => array(  ),
'recsPerRow' => 1 ),
'above-grid' => array( 'modelId' => 'empty-above-grid',
'grid' => array(  ),
'cells' => array(  ),
'deferredItems' => array(  ),
'recsPerRow' => 1 ),
'grid' => array( 'modelId' => 'welcome',
'grid' => array( array( 'cells' => array( array( 'cell' => 'c1' ) ),
'section' => '' ) ),
'cells' => array( 'c1' => array( 'model' => 'c1',
'items' => array(  ),
'_t' => 'Map',
'_i' => array(  ),
'_s' => 0 ) ),
'deferredItems' => array(  ),
'recsPerRow' => 1 ) ),
'items' => array( 'logo' => array( 'type' => 'logo',
'color' => '#ffffff',
'background' => 'transparent',
'customCSS' => '/* Put  your custom CSS code here */

.navbar-brand{
    width: 200;
}' ),
'menu' => array( 'type' => 'menu',
'background' => 'transparent',
'color' => '#ffffff',
'menuId' => 'main',
'customCSS' => '/* Put  your custom CSS code here */

:host {
  color: red;
}
.navbar-brand{
    width: 200;
}' ) ),
'dbProps' => array(  ),
'version' => 4,
'pageWidth' => 'full',
'menuWidth' => 'full',
'fixedTopbar' => false );
		?>